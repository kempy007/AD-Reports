﻿$arrLastLogon = @()

function Get-ADUserLastLogon([string]$userName)
{ # "http://technet.microsoft.com/en-us/library/dd378867(v=ws.10).aspx"

  $time = 0
  foreach($dc in $dcs)
  { 
    $hostname = $dc.HostName
    $user = Get-ADUser $userName | Get-ADObject -Server $hostname -Properties lastLogon 
    if($user.LastLogon -gt $time) 
    {
      $time = $user.LastLogon
      $AuthDC = $hostname
    }
  }
  $dt = [DateTime]::FromFileTime($time)
  #Write-Host $username "last logged on at:" $AuthDC $dt
  Add-Content C:\TS-Job\data\AD_User_Last_Logon.csv $username","$AuthDC","$dt
  # | Export-Csv .\domain-admins.csv
}

Import-Module ActiveDirectory
$dcs = Get-ADDomainController -Filter {Name -like "*"}
$arrNames = Get-ADUser -Filter * -SearchBase "ou=MHBS,dc=MHBS,dc=local" | foreach { $_.sAMACcountName} | Sort


foreach($usr in $arrNames) 
{
    Get-ADUserLastLogon -UserName $usr
}
