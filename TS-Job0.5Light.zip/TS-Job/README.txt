Extract to root of C: drive like c:\TS-Job so that paths do not break.
Requires Java as job was built in talend studio.
Requires powershell and the AD Module, install Active Directory Management Gateway Service 
 (Active Directory Web Service for Windows Server 2003 and Windows Server 2008) from dependancies folder. Or for Win7 install the RSAT tools.
Requires 'Network Service' account to run the task as.
set scheduled task for C:\TS-Job\ProcessReport\ProcessReport_run.bat

Had to edit above script to include an updated java path before the java command;
set PATH=%PATH%;C:\TS-Job\jre1.8.0_111\bin


Also had to run as the service user from cmd.exe
c:\windows\syswow64\WindowsPowerShell\v1.0\powershell.exe -command set-executionpolicy unrestricted